import React from "react";

import Title from "./Header/Title";

export default class Header extends React.Component {

  handlechange(e)
  {
    const titleval = e.target.value;
    this.props.titlechange(titleval);
  }
  render() {
   
    return (
      <div>
        <Title />
        <h1>{this.props.title}</h1>
        <input type="text"  value={this.props.title} onChange={this.handlechange.bind(this)} />
      </div>
    );
  }

}
